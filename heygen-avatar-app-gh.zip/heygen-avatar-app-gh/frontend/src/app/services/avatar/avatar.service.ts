import { Injectable } from '@angular/core';
import StreamingAvatar, {
  StartAvatarRequest,
  StreamingEvents,
  AvatarQuality,
  VoiceChatTransport,
  VoiceEmotion,
  STTProvider,
  ElevenLabsModel,
  TaskType
} from '@heygen/streaming-avatar';

@Injectable({ providedIn: 'root' })
export class AvatarService {
  private avatar: StreamingAvatar | null = null;
  

  config: StartAvatarRequest = {
    quality: AvatarQuality.Medium,
    avatarName: 'Elenora_IT_Sitting_public',
    knowledgeId: undefined,
    voice: {
      rate: 1.5,
      emotion: VoiceEmotion.EXCITED,
      model: ElevenLabsModel.eleven_flash_v2_5,
    },
    language: "en",
    voiceChatTransport: VoiceChatTransport.WEBSOCKET,
    sttSettings: {
      provider: STTProvider.DEEPGRAM,
    },
  };

  async fetchToken(): Promise<string> {
    const response = await fetch('http://localhost:3001/api/get-access-token', { method: 'POST' });
    return await response.text();
  }

  async startAvatarSession(): Promise<MediaStream | null> {
    const token = await this.fetchToken();
    this.avatar = new StreamingAvatar({token});
    this.avatar.on(StreamingEvents.AVATAR_START_TALKING, () => console.log('Avatar is talking'));
    const sessionData =await this.avatar.createStartAvatar(this.config);
    this.avatar.startVoiceChat();
    console.log('Session started:', sessionData.session_id);
    await this.avatar.speak({
      text: 'Hello, world!',
      task_type: TaskType.REPEAT
    });
    return this.avatar.mediaStream
  }

  stopSession(): void {
    this.avatar?.stopAvatar();
    this.avatar = null;
  }

}