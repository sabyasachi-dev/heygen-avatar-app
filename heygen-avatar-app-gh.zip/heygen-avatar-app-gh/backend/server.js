const express = require('express');
const fetch = require('node-fetch');
const dotenv = require('dotenv');
const cors = require('cors');

dotenv.config();

const app = express();
app.use(express.json());
app.use(cors());


const PORT = process.env.PORT || 3001;
const HEYGEN_API_URL = `${process.env.NEXT_PUBLIC_BASE_API_URL}/v1/streaming.create_token`;

app.post('/api/get-access-token', async (req, res) => {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_API_URL}/v1/streaming.create_token`, {
      method: 'POST',
      headers: {
        "x-api-key": `${process.env.HEYGEN_SECRET_KEY}`,
      }
    });

    console.log("Response:", response);
    const data = await response.json();
    if (data.data.token) {
      res.send(data.data.token);
    } else {
      res.status(400).send('Failed to retrieve token');
    }
  } catch (error) {
    console.error('Token fetch error:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/', (req, res) => res.send('Server is alive'));

app.listen(PORT, () => {
  console.log(`HeyGen Express server running at http://localhost:${PORT}`);
});