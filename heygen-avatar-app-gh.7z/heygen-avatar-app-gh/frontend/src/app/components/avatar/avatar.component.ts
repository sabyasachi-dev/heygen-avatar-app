import { Component, ElementRef, ViewChild } from '@angular/core';
import { AvatarService } from '../../services/avatar/avatar.service';

@Component({
  selector: 'app-avatar',
  templateUrl: './avatar.component.html',
  styleUrls: ['./avatar.component.scss']
})
export class AvatarComponent {
  @ViewChild('videoRef') videoRef!: ElementRef<HTMLVideoElement>;
  isRunning = false;

  constructor(private avatarService: AvatarService) {}

  async start() {
    const stream = await this.avatarService.startAvatarSession();
    if (stream && this.videoRef) {
      this.videoRef.nativeElement.srcObject = stream;
      this.videoRef.nativeElement.play();
      this.isRunning = true;
    }
  }

  stop() {
    this.avatarService.stopSession();
    this.isRunning = false;
  }
}